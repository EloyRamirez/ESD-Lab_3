/* This is a C program written for the timer interrupt demo.  The 
 program assumes a nios_system with a periodic interrupt timer
 and an 8-bit output PIO named leds. */


/* alt_types.h and sys/alt_irq.h need to be included for the interrupt
  functions
  system.h is necessary for the system constants
  io.h has read and write functions */
#include "io.h"
#include <stdio.h>
#include "system.h"
#include "alt_types.h"
#include "sys/alt_irq.h"
#include "altera_avalon_timer_regs.h"
#include "altera_avalon_timer.h"
#define HexZero 0x40
#define HexOne 0x79
#define HexTwo 0x24
#define HexThree 0x30
#define HexFour 0x19
#define HexFive 0x12
#define HexSix 0x02
#define HexSeven 0x78
#define HexEight 0x00
#define HexNine 0x10

hexArray[10] = { HexZero, HexOne, HexTwo, HexThree, HexFour, HexFive, HexSix, HexSeven, HexEight, HexNine};


// create standard embedded type definitions
typedef   signed char   sint8;              // signed 8 bit values
typedef unsigned char   uint8;              // unsigned 8 bit values
typedef   signed short  sint16;             // signed 16 bit values
typedef unsigned short  uint16;             // unsigned 16 bit values
typedef   signed long   sint32;             // signed 32 bit values
typedef unsigned long   uint32;             // unsigned 32 bit values
typedef         float   real32;             // 32 bit real values

//set up pointers to peripherals

//uint32* TimerPtr    = (uint32*)TIMER_0_BASE;

//unsigned char* LedPtr      = (unsigned char*)LEDS_BASE;

unsigned long *switchesBase_ptr = (unsigned long *) SWITCHES_BASE;
unsigned long *ledsBase_ptr     = (unsigned long *) LEDS_BASE;
unsigned long *hex0Base_ptr	   = (unsigned long*)HEX0_BASE;
unsigned long *pushButtonBase_ptr	   = (unsigned long*)PUSHBUTTONS_BASE;
unsigned long *timerBase_ptr	=	(unsigned long*)TIMER_0_BASE;

unsigned long switch_val; //temp storage
unsigned long pushB_val;
unsigned long hex_val;
unsigned char led_val;

int counter = 0;

void pushButton_isr(void *context)
/*****************************************************************************/
/* Interrupt Service Routine                                                 */
/*   Determines what caused the interrupt and calls the appropriate          */
/*  subroutine.                                                              */
/*                                                                           */
/*****************************************************************************/
{

   //while(1) {
	  *(pushButtonBase_ptr + 3) = 0x02;

	  pushB_val = *pushButtonBase_ptr;

	  if(pushB_val != 0xD)
	  {
		  
		  switch_val = *switchesBase_ptr;
		  
		  if(switch_val == 0x01)
		  {
			  if(counter >= 9)
			  {
				  counter = counter - 1;
			  }
			  
			  counter = counter + 1;
			  hex_val = hexArray[counter];
		  }
		  else
		  {
			  if(counter <= 0)
			  {
				  counter = counter + 1;
			  }
			  
			  counter = counter - 1;
			  hex_val = hexArray[counter];
		  }
		  
		  while(pushB_val == 0xD)
		  {
			  pushB_val = *pushButtonBase_ptr;
		  }
	  }

	  *hex0Base_ptr = hex_val;

      //*ledsBase_ptr = switch_val;        // put sw value on leds
   //}

    return;
}

void timer_isr(void *context)
/*****************************************************************************/
/* Interrupt Service Routine                                                 */
/*   Determines what caused the interrupt and calls the appropriate          */
/*  subroutine.                                                              */
/*                                                                           */
/*****************************************************************************/
{

	*timerBase_ptr = 0x00;

	led_val = *ledsBase_ptr;

   if(led_val == 0x00)
   {
	   led_val = 0XFF;
   }
   else
   {
	   led_val = 0x00;
   }

   *ledsBase_ptr = led_val;


    return;
}


int main(void)
/*****************************************************************************/
/* Main Program                                                              */
/*   Enables interrupts then loops infinitely                                */
/*****************************************************************************/
{
    /* this enables the NIOS II to accept a TIMER interrupt 
     * and indicates the name of the interrupt handler */
	hex_val = hexArray[counter];

	*hex0Base_ptr = hexArray[counter]; /* initial value to hex0 */

	*ledsBase_ptr = 0x00;

	alt_ic_isr_register(PUSHBUTTONS_IRQ_INTERRUPT_CONTROLLER_ID,PUSHBUTTONS_IRQ,pushButton_isr,0,0);
	alt_ic_isr_register(TIMER_0_IRQ_INTERRUPT_CONTROLLER_ID,TIMER_0_IRQ,timer_isr,0,0);

	*(pushButtonBase_ptr + 2) = 0x0F;


    while(1);
    return 0;
}
